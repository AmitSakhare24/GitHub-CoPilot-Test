package com.cognixia.jump.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognixia.jump.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {

	public List<Student> findByMajor(String major);
	
	@Query("select s from Student s where s.major = ?1")
	public List<Student> studentsInMajor(String major);

	@Transactional
	@Modifying
	@Query(" UPDATE Student s SET s.major= :major WHERE s.id = :id ")
	public int updateMajor(@Param(value="id") int id, @Param(value="major") String major);
	
}












