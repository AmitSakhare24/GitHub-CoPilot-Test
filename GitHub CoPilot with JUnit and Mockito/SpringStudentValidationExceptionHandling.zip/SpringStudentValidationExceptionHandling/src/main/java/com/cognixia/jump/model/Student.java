package com.cognixia.jump.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;


@Entity
public class Student implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;
	
	// @NotBlank -> strings cannot be null, empty strings, or full of just whitespace
	@NotBlank(message = "First name cannot be left blank")
	@Column(name="fname")
	private String firstName;
	
	// validations don't always need a message
	@NotBlank
	private String lastName;
	
	
	// @Pattern -> check a string against a regex
	@Pattern(regexp = "^.+@.+$") 				// checks if email has @ character
	@Column(unique = true, nullable = false)
	private String email;
	
	// @Min -> minimum value
	// @Max -> maximum value
	@Min(value = 0)
	@Max(value = 4)
	private Double gpa;
	
	private LocalDate dob;
	
	@Column( columnDefinition = "varchar(100) DEFAULT 'Undecided' " )
	private String major;
	
	
	
	public Student() {
		
	}

	public Student(int id, String firstName, String lastName, String email, double gpa, LocalDate dob, String major) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.gpa = gpa;
		this.dob = dob;
		this.major = major;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Double getGpa() {
		return gpa;
	}

	public void setGpa(Double gpa) {
		this.gpa = gpa;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", gpa=" + gpa + ", dob=" + dob + ", major=" + major + "]";
	}
	
	
	// DO NOT ADD THE FOLLOWING 3 METHODS UNTIL LATER WHEN DOING THE TESTING EXAMPLES
	
	
	public String toJson() {

		return "{\"id\" : " + id 
				+ ", \"firstName\" : \"" + firstName + "\""
				+ ", \"lastName\" : \"" + lastName + "\""
				+ ", \"email\" : \"" + email + "\""
				+ ", \"gpa\" : " + gpa 
				+ ", \"dob\" : \"" + dob + "\""
				+ ", \"major\" : \"" + major + "\"}";
	}

	@Override
	public int hashCode() {
		return Objects.hash(dob, email, firstName, gpa, id, lastName, major);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(dob, other.dob) && Objects.equals(email, other.email)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(gpa, other.gpa)
				&& Objects.equals(id, other.id) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(major, other.major);
	}
	
	

}
