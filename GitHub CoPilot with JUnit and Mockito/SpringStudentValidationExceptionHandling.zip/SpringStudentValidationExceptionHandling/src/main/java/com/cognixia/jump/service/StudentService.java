package com.cognixia.jump.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Student;
import com.cognixia.jump.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository repo;
	
	
	public List<Student> getStudents() {
		
		return repo.findAll();
	}
	
	public Student getStudentById(int id) throws ResourceNotFoundException {
		
		Optional<Student> found = repo.findById(id);
		
		if(found.isEmpty()) {
			throw new ResourceNotFoundException("Student", id);
		}
		
		return found.get();
	}
	
	public Student createStudent(Student student) {
		
		student.setId(null);
		
		Student created = repo.save(student);
		
		return created;
	}
	
	public Student updateStudent(Student student) throws ResourceNotFoundException {
		
		boolean exists = repo.existsById(student.getId());
		
		if(exists) {
		
			Student updated = repo.save(student);
			
			return updated;
			
		}
		
		throw new ResourceNotFoundException( "Student", student.getId() );
	}
	
	public boolean deleteStudent(int id) throws ResourceNotFoundException {
		
		boolean exists = repo.existsById(id);
		
		if(exists) {
			
			repo.deleteById(id);
			
			return true;
			
		}
		
		throw new ResourceNotFoundException("Student", id);
	}
	
	public List<Student> getByMajor(String major) {
		
		//return repo.findByMajor(major);

		return repo.studentsInMajor(major);
	}
	
	public Student updateMajor(int id, String major) throws ResourceNotFoundException {
		
		int count = repo.updateMajor(id, major);
		
		if( count > 0 ) {
			return getStudentById(id);
		}
		
		throw new ResourceNotFoundException("Student", id);
	}
	
}




















