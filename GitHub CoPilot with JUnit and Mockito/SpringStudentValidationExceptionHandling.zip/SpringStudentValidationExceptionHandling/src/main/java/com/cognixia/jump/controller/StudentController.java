package com.cognixia.jump.controller;

import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Student;
import com.cognixia.jump.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	StudentService service;
	
	@GetMapping("/student")
	public List<Student> getStudents() {
		
		// services
		return service.getStudents();
	}
	
	@GetMapping("/student/{id}")
	public ResponseEntity<?> getStudent(@PathVariable int id) throws ResourceNotFoundException {
		
		Student found = service.getStudentById(id);
		
		return ResponseEntity.status(200).body( found );
		
	}
	
	// @Valid -> makes sure to validate the student data sent & will give a
	//			 400 level status code if validation violated 
	
	@PostMapping("/student")
	public ResponseEntity<?> createStudent(@Valid @RequestBody Student student) {
		
		Student created = service.createStudent(student);
		
		return ResponseEntity.status(201).body(created);
	}
	
	@PutMapping("/student")
	public ResponseEntity<?> updateStudent(@Valid @RequestBody Student student) throws ResourceNotFoundException {
		
		Student updated = service.updateStudent(student);
		
		return ResponseEntity.status(200)
							 .body(updated);
		
	}
	
	@DeleteMapping("/student/{id}")
	public ResponseEntity<?> deleteStudent(@PathVariable int id) throws ResourceNotFoundException {
		
		service.deleteStudent(id);
			
		return ResponseEntity.status(200)
							 .body("Deleted Student with id = " + id);
	
	}
		
	
	@GetMapping("/student/major/{major}")
	public List<Student> getStudentsByMajor(@PathVariable String major) {
		return service.getByMajor(major);
	}
	
	@PatchMapping("/student/major")
	public ResponseEntity<?> updateMajor(@PathParam(value = "id") int id, @PathParam(value = "major") String major) throws ResourceNotFoundException {
		
		Student updated = service.updateMajor(id, major);
		
		return ResponseEntity.status(200)
							 .body(updated);
		
		
	}
	
	@PatchMapping("/student/major/v2")
	public ResponseEntity<?> updateMajor2(@RequestBody Map<String, String> info) throws ResourceNotFoundException {
		
		int id = Integer.parseInt( info.get("id") );
		String major = info.get("major");
		
		Student updated = service.updateMajor(id, major);
		
		return ResponseEntity.status(200)
							 .body(updated);
		
	}
	
}


















