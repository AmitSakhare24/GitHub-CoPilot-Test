package com.cognixia.jump.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Student;
import com.cognixia.jump.service.StudentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//@ExtendWith(SpringExtension.class) // may not be necessary for your project
@WebMvcTest(StudentController.class)
public class StudentControllerTest {

private static final String STARTING_URI = "http://localhost:8080/api";
	
	// mocking the request/response
	@Autowired
	private MockMvc mvc;
	
	// mock the method calls for the service
	// we decide what data gets returned from the service methods instead
	@MockBean
	private StudentService service;
	
	// when the controller tries to autowire the service,
	// mock the creation of the service
	@InjectMocks
	private StudentController controller;
	
	
	@Test
	void testGetStudents() throws Exception {

		// uri for the request
		String uri = STARTING_URI + "/student";

		// the data that will be returned by the service when
		// getStudents() method is called
		List<Student> allStudents = new ArrayList<Student>();
		allStudents.add( new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music") );
		allStudents.add( new Student(2, "Sharpay", "Evans", "sharpay@gmail.com", 3.8, LocalDate.of(1990, 6, 1), "Theater") );
		
		// when service.getStudents() is called by the controller
		// return this list of students instead of doing the actual method call
		when( service.getStudents() ).thenReturn(allStudents);
		
		
		// for the text below, you do not need to do every single test for each attribute for each student in
		// the array, you can do a few or just copy paste the code and go over it
		
		mvc.perform( get(uri) )   // perform get request
				.andDo( print() ) // print request sent/response given
				.andExpect( status().isOk() ) // expect a 200 status code
				.andExpect( content().contentType( MediaType.APPLICATION_JSON_VALUE ) ) // checks content type is json
				.andExpect( jsonPath( "$.length()" ).value( allStudents.size() ) ) // length of the list matches one above
				.andExpect( jsonPath("$[0].id").value(allStudents.get(0).getId()) ) // check each column value for the cars in list
				.andExpect( jsonPath("$[0].firstName").value(allStudents.get(0).getFirstName() ) )
				.andExpect( jsonPath("$[0].lastName").value(allStudents.get(0).getLastName() ) )
				.andExpect( jsonPath("$[0].email").value(allStudents.get(0).getEmail() ) )
				.andExpect( jsonPath("$[0].gpa").value(allStudents.get(0).getGpa() ) )
				.andExpect( jsonPath("$[0].dob").value(allStudents.get(0).getDob().toString() ) ) // make sure to match the string value, won't work if just compare the LocalDate object
				.andExpect( jsonPath("$[0].major").value(allStudents.get(0).getMajor() ) )
				.andExpect( jsonPath("$[1].id").value(allStudents.get(1).getId()) ) 
				.andExpect( jsonPath("$[1].firstName").value(allStudents.get(1).getFirstName() ) )
				.andExpect( jsonPath("$[1].lastName").value(allStudents.get(1).getLastName() ) )
				.andExpect( jsonPath("$[1].email").value(allStudents.get(1).getEmail() ) )
				.andExpect( jsonPath("$[1].gpa").value(allStudents.get(1).getGpa() ) )
				.andExpect( jsonPath("$[1].dob").value( allStudents.get(1).getDob().toString() ) )
				.andExpect( jsonPath("$[1].major").value(allStudents.get(1).getMajor() ) );
		
		// verify how many times a method was called (how many times methods from service 
		// were used)
		verify( service, times(1) ).getStudents(); // getStudents() from service called once
		verifyNoMoreInteractions( service ); // after checking above, service is no longer called
		
	}
	
	
	@Test
	void testGetStudentById() throws Exception {
		
		int id = 1;
		String uri = STARTING_URI + "/student/{id}";
		
		// student that will be returned by service
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		// when service called, return this car object
		when( service.getStudentById(id) ).thenReturn(student);
		
		mvc.perform( get(uri, id) ) // create get request and pass id to uri path
				.andDo( print() )
				.andExpect( status().isOk() )
				.andExpect( content().contentType( MediaType.APPLICATION_JSON_VALUE ) )
				.andExpect( jsonPath("$.id").value(student.getId()) ) 
				.andExpect( jsonPath("$.firstName").value(student.getFirstName() ) )
				.andExpect( jsonPath("$.lastName").value(student.getLastName() ) )
				.andExpect( jsonPath("$.email").value(student.getEmail() ) )
				.andExpect( jsonPath("$.gpa").value(student.getGpa() ) )
				.andExpect( jsonPath("$.dob").value(student.getDob().toString() ) )
				.andExpect( jsonPath("$.major").value(student.getMajor() ) )
				;
		
		verify( service, times(1) ).getStudentById(id);
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testStudentByIdNotFound() throws Exception {
		
		int id = 1;
		String uri = STARTING_URI + "/student/{id}";
		
		// when this method gets called, this time an exception will be thrown
		when( service.getStudentById(id) )
			.thenThrow( new ResourceNotFoundException("Student", id) );
		
		// because of the exception, we're only checking to make sure we got the expected 404 status code
		mvc.perform( get(uri, id) )
			.andDo( print() )
			.andExpect( status().isNotFound() );
		
		// verify the calls made
		verify( service, times(1) ).getStudentById(id);
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testCreateStudent() throws Exception {
		
		String uri = STARTING_URI + "/student";
		
		Student student = new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		// when we attempt to add the student, we don't care what kind of student was sent
		// through the request or to the service, what we care about is the student returned
		// as a response
		when( service.createStudent( Mockito.any(Student.class) ) ).thenReturn(student);
		
		
		// NOTE: The toJson() method used below is one we created and located as the last method in the
		//		 Student model file. In order to send our object in the body, we must convert it to JSON,
		//		 so this method takes care to do that. Can also use asJsonString() at the bottom of the file
		//		 here as an alternative if it doesn't work.
		
		mvc.perform( post(uri)
					.content( student.toJson() ) // data sent in body NEEDS to be in JSON format
					.contentType(MediaType.APPLICATION_JSON_VALUE) )
			.andDo( print() )
			.andExpect( status().isCreated() )
			.andExpect( content().contentType( MediaType.APPLICATION_JSON_VALUE ) );
		
	}
	
	
	@Test
	void testUpdateStudent() throws Exception {
		
		String uri = STARTING_URI + "/student";
		
		Student student = new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		
		when( service.updateStudent( Mockito.any(Student.class) ) ).thenReturn(student);
		
		mvc.perform( put(uri)
						 .contentType(MediaType.APPLICATION_JSON_VALUE)
						 .content( student.toJson() ) )
				.andExpect(status().isOk());
		
		verify(service, times(1)).updateStudent(Mockito.any(Student.class));
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testUpdateStudentNotFound() throws Exception {
		
		String uri = STARTING_URI + "/student";
		int id = 1;
		
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		
		when(service.updateStudent( Mockito.any(Student.class)))
			.thenThrow(new ResourceNotFoundException("Student", id));
		
		mvc.perform( put(uri)
						 .contentType(MediaType.APPLICATION_JSON_VALUE)
						 .content( student.toJson() ) )
				.andExpect(status().isNotFound());
		
		verify(service, times(1)).updateStudent( Mockito.any(Student.class) );
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testDeleteStudent() throws Exception {
		
		String uri = STARTING_URI + "/student/{id}";
		int id = 1;
		
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		
		when( service.deleteStudent(id) ).thenReturn(true);
		
		
		mvc.perform( delete(uri, id) )
				.andDo( print() )
				.andExpect( status().isOk() );
				// can do more tests to make sure json data formatted properly
		
		verify( service, times(1) ).deleteStudent(id);
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testDeleteStudentNotFound() throws Exception {
		
		String uri = STARTING_URI + "/student/{id}";
		int id = 1;
		
		when( service.deleteStudent(id) )
			.thenThrow( new ResourceNotFoundException("Student", id) );
		
		
		mvc.perform( delete(uri, id) )
				.andExpect( status().isNotFound() );
		
		
		verify( service, times(1) ).deleteStudent(id);
		verifyNoMoreInteractions(service);
	}
	
	
	// OPTIONAL EXERCISE: Ask students to finish the rest of the file and do the rest of the testing
	
	
	@Test
	void testGetStudentsByMajor() throws Exception {
		
		String uri = STARTING_URI + "/student/major/{major}";
		String major = "Music";
		
		List<Student> allStudents = new ArrayList<Student>();
		allStudents.add( new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), major) );
		allStudents.add( new Student(2, "Sharpay", "Evans", "sharpay@gmail.com", 3.8, LocalDate.of(1990, 6, 1), major) );
		
		
		when( service.getByMajor(major) ).thenReturn( allStudents );
		
		// This only tests if we get back a 200 status code, but can be expanded to check each piece of json data if need be
		mvc.perform( get(uri, major) )
				.andExpect( status().isOk() );
		
		verify( service, times(1) ).getByMajor(major);
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testUpdateMajor() throws Exception {
		
		int id = 1;
		String major = "Music";
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), major);
		
		String uri = STARTING_URI + "/student/major?id=" + id + "&major=" + major;
		
		
		when( service.updateMajor(id, major) ).thenReturn( student );
		
		mvc.perform( patch(uri) )
				.andExpect( status().isOk() );
		
		verify( service, times(1) ).updateMajor(id, major);
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testUpdateMajorNotFound() throws Exception {
		
		int id = 1;
		String major = "Music";
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), major);
		
		String uri = STARTING_URI + "/student/major?id=" + id + "&major=" + major;
		
		
		when( service.updateMajor(id, major) )
			.thenThrow( new ResourceNotFoundException("Student", id) );
		
		mvc.perform( patch(uri) )
				.andExpect( status().isNotFound() );
		
		verify( service, times(1) ).updateMajor(id, major);
		verifyNoMoreInteractions(service);
	}
	
	@Test
	void testUpdateMajor2() throws Exception {
		
		int id = 1;
		String major = "Music";
		
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), major);
		
		// map that will be used to send data
		Map<String, String> info = new HashMap<String, String>();
		info.put("id", id + "");
		info.put("major", major);
		
		String uri = STARTING_URI + "/student/major/v2";
		
		
		when( service.updateMajor(id, major) ).thenReturn( student );
		
		mvc.perform( patch(uri)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content( asJsonString(info) )
					)
				.andExpect( status().isOk() );
		
		verify( service, times(1) ).updateMajor(id, major);
		verifyNoMoreInteractions(service);
	}
	
	
	@Test
	void testUpdateMajor2NotFound() throws Exception {
		
		int id = 1;
		String major = "Music";
		
		// map that will be used to send data
		Map<String, String> info = new HashMap<String, String>();
		info.put("id", id + "");
		info.put("major", major);
		
		String uri = STARTING_URI + "/student/major/v2";
		
		
		when( service.updateMajor(id, major) )
				.thenThrow( new ResourceNotFoundException("Student", id) );
		
		mvc.perform( patch(uri)
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content( asJsonString(info) )
					)
				.andExpect( status().isNotFound() );
		
		verify( service, times(1) ).updateMajor(id, major);
		verifyNoMoreInteractions(service);
	}
	
	
	
	// converts any object to a JSON string
	public static String asJsonString(final Object obj) {
		
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		
	}
	
}





















