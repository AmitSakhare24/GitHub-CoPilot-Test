package com.cognixia.jump.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Student;
import com.cognixia.jump.repository.StudentRepository;

@ExtendWith(MockitoExtension.class)
public class StudentServiceTest {
	
	// mock the request methods
	@Mock
	private StudentRepository repo;

	// don't want service to autowire the repository,
	// use the "mocked" repo
	@InjectMocks
	private StudentService service;
	
	
	@Test
	void testGetStudents() throws Exception {
		
		// ARRANGE
		
		List<Student> allStudents = new ArrayList<Student>();
		allStudents.add( new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music") );
		allStudents.add( new Student(2, "Sharpay", "Evans", "sharpay@gmail.com", 3.8, LocalDate.of(1990, 6, 1), "Theater") );
		
		when( repo.findAll() ).thenReturn(allStudents);
		
		
		// ACT
		
		List<Student> result = service.getStudents();
		
		
		// ASSET
		
		// BEFORE SETTING UP FOR LOOP: Make sure that you have generated an equals() method
		// for the Student.java model class. Go to Source -> Generate hashCode() and equals()...
		// option in order to have eclipse create the method for you
		
		for( int i = 0; i < allStudents.size(); i++ ) {
			
			if( allStudents.get(i).equals( result.get(i) ) ) {
				System.out.println("Equal");
			}
			else {
				
				// if there is no assertion used, then the test will always succeed. So you
				// can use fail() to make the test fail when you need to
				fail();
			}	
		}	
	}
	
	
	@Test
	void testGetStudentById() throws Exception {
		
		// ARRANG: id and car to use
		int id = 1;
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		// call the repository, make sure it returns an optional of this student
		when( repo.findById(id) ).thenReturn( Optional.of(student) );
		
		// ACT: testing to see what this method returns
		Student result = service.getStudentById(id);
		
		// ASSERT: car and result are the same
		assertEquals(student, result);
	}
	
	
	@Test
	void testGetStudentByIdNotFound() throws Exception {
		
		// ARRANG: id and car to use
		int id = 1;
		
		// call the repository, make sure it returns an optional of this car
		when( repo.findById(id) ).thenReturn( Optional.empty() );
		
		assertThrows(ResourceNotFoundException.class,  () -> {
			service.getStudentById(id);
		});
	}
	
	@Test
	void testUpdateStudent()throws Exception {
		
		Student student = new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		when( repo.existsById(student.getId()) ).thenReturn(true);
		when( repo.save(Mockito.any()) ).thenReturn(student);
		
		Student created = service.updateStudent(student);
		
		// assertEquals() -> will successfully compare two objects
		// as long as you have an equals() method defined in the 
		// model class they come from
		assertEquals(student, created);
		
	}
	
	@Test
	void testUpdateStudentNotFound() throws Exception {
		
		Student student = new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), "Music");
		
		when( repo.existsById(student.getId()) ).thenReturn(false);
		
		
		assertThrows(ResourceNotFoundException.class, () -> {
			service.updateStudent(student);
		});
		
	}
	
	@Test
	void testDeleteStudent() throws Exception {
		
		int id = 1;
		
		when(repo.existsById(id)).thenReturn(true);
		
		boolean deleted = service.deleteStudent(id);
		
		assertTrue(deleted);
	}
	
	@Test
	void testDeleteStudentNotFound() throws Exception {
		
		int id = 1;
		
		when(repo.existsById(id)).thenReturn(false);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			service.deleteStudent(id);
		});
	}
	
	@Test
	void testGetByMajor() throws Exception {
		
		String major = "History";
		
		List<Student> studentsInSameMajor = new ArrayList<Student>();
		studentsInSameMajor.add( new Student(1, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), major) );
		studentsInSameMajor.add( new Student(2, "Sharpay", "Evans", "sharpay@gmail.com", 3.8, LocalDate.of(1990, 6, 1), major) );
		
		when(repo.studentsInMajor(major)).thenReturn(studentsInSameMajor);
		
		
		List<Student> result = service.getByMajor(major);
		
		for( int i = 0; i < studentsInSameMajor.size(); i++ ) {
			
			if( studentsInSameMajor.get(i).equals( result.get(i) ) ) {
				System.out.println("Equal");
			}
			else {
				fail();
			}	
		}	
	}
	
	@Test
	void testUpdateMajor() throws Exception {
		
		int id = 1;
		String major = "Math";
		Student student = new Student(id, "Peppa", "Pig", "peppa@gmail.com", 3.4, LocalDate.of(2004, 5, 30), major);
		
		when(repo.updateMajor(id, major)).thenReturn(1);
		when(repo.findById(id)).thenReturn(Optional.of(student));
		
		Student updated = service.updateMajor(id, major);
		
		assertEquals(student, updated);
		
	}
	
	@Test
	void testUpdateMajorNotFound() throws Exception {
		
		int id = 1;
		String major = "Math";
		
		when( repo.updateMajor(id, major) ).thenReturn(0);		
		
		assertThrows(ResourceNotFoundException.class, () -> {
			service.updateMajor(id, major);
		});
		
	}
	
	

}


















