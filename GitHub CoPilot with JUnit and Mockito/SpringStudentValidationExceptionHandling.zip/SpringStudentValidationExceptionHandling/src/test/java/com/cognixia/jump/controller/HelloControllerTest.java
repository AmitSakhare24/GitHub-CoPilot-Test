package com.cognixia.jump.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

// This is a test for the hello controller and we're going to mock
// and test the request/response processing done by the controller
// @ExtendWith(SpringExtension.class) // can remove if get warning that this line not necessary
@WebMvcTest(HelloController.class)
public class HelloControllerTest {
	
	// Mockito library class
	// MockMvc -> mocks the request/responses
	@Autowired
	private MockMvc mvc;
	
	
	@Test
	void testHello() throws Exception {
		
		// Steps: ARRANGE, ACT, ASSERT
		
		// ARRANGE --> put together info needed
		String name = "O";
		String uri = "/api/hello/" + name;
		
		// mockito can be used to create a request
		// below we create a get request at the uri we specify 
		RequestBuilder request = MockMvcRequestBuilders.get(uri);
		
		
		// ACT --> performing test
		
		// perform the request to the api and return the response
		MvcResult result = mvc.perform(request).andReturn();
		
		
		// ASSERT --> did the test pass?
		
		// "Hello <name>" --> expected result
		// result.getResponse().getContentAsString() --> get the string within the body of the response
		assertEquals("Hello " + name, result.getResponse().getContentAsString() );
		
	}
	
	
	@Test
	void testHello2() throws Exception {
		
		String name = "World";
		String uri = "/api/hello/" + name;
		
		// notice how methods like get() can be imported with a static import, that way you can import just this get method
		// without importing the whole MockMvcRequestBuilders class, where the get method is from
		
		mvc.perform( get(uri) ) // perform a get request at the uri
			.andExpect( content().string( "Hello " + name ) );	// assert content matches "Hello O"	
	}
	
	
	
	

}
